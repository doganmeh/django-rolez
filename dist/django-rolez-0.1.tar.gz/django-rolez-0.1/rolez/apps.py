from django.apps import AppConfig


class RolezConfig(AppConfig):
    name = 'rolez'
